{% with model_verbose_name="admin user" model_verbose_name_plural="admin users" %}
{% include "api/sub_list_create_api_view.md" %}
{% endwith %}